def sumar (op1,op2):
    print(f"El resultado de la suma es {op1+op2}")

def restar (op1,op2):
    print(f"El resultado de la resta es {op1-op2}")

def multiplicar (op1,op2):
    print(f"El resultado de la mnultiplicacion es {op1*op2}")

def dividir(numerador, denominador):
    print(f"El resultado de la division es {numerador/denominador}")

def potencia(base, exponente):
    print(f"El resultado de la potencia es {base**exponente}")

def redondear(numero):
    print(f"El numero redondeado queda como: {round(numero)}")