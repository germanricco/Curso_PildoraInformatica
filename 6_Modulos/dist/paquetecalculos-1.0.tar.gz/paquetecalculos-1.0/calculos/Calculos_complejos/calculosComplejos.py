def potencia(base, exponente):
    print(f"El resultado de la potencia es {base**exponente}")

def redondear(numero):
    print(f"El numero redondeado queda como: {round(numero)}")